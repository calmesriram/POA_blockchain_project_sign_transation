import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

declare var require: any;
declare let Web3: any;
var contractAddress = "0xc7fce6f31131c17be265f2b851087ef57b41f5f8";
var privatekey = "0x81ED94E347EAA804802C716AAB5D00FEB343ED4BA7D8149B6349AC0D3C41F6DC";
var contractAbi = require('../assets/contractfiles/abi.json');
const web3 = new Web3(new Web3.providers.HttpProvider('https://ropsten.infura.io/v3/b368f72affd24424b558cac66853289d'));
let myContract = new web3.eth.Contract(contractAbi, contractAddress, {
  // from: this.owner,
  gasLimit: 3000000,
});
var util = require('ethereumjs-util')
var Buffer = require('buffer/').Buffer
@Injectable({
  providedIn: 'root'
})
export class ApiService {
  public companyid: any;

  constructor(public http: HttpClient, public toster: ToastrService) {
    console.log(web3.version)

  }

  // sendfile(data){
  //   // ipfs.add(data, function (err, result) {
  //   //   if(err){
  //   //     console.log(err,"err");
  //   //   }
  //   //   if(result){
  //   //     console.log(result)
  //   //   }
  //   // })
  // }

  txstatus(txhash): Promise<any> {

    return new Promise((resolve, reject) => {

      var clear = setInterval(() => {
        web3.eth.getTransactionReceipt(txhash, (err, res) => {
          if (res["status"] != null) {
            if (res["status"] == "0x1") {
              console.log("success")
              clearInterval(clear);
              resolve("success");

            }
            else {
              console.log("unsucess");
              clearInterval(clear);
              resolve("failed")
              this.toster.error("failed", "Transaction Status")
            }
          } else {

          }
        })

      }, 1000)

    }).catch((e) => {
      console.log(e)
      this.toster.error(e, "Transaction Status")
    }) as Promise<any>;

  }

  // getpubkeyAndAddress(pvtkeyData) {
  //   return new Promise((resolve, reject) => {
  //     var buf_enc = Buffer.from(pvtkeyData, 'hex');
  //     let publickey = util.privateToPublic(buf_enc)
  //     let data = web3.eth.accounts.privateKeyToAccount("0x" + pvtkeyData)
  //     console.log(data);
  //     resolve({ "address": data.address, "publicKey": '0x04' + publickey.toString('hex'), "privateKey": data.privateKey })
  //   })
  // }
  public async getaddressid(dataaddress): Promise<any> {
    return new Promise((resolve, reject) => {
      myContract.methods.addressToCompany(dataaddress).call(function (error, result) {
        if (error) {
          console.log(error)
          resolve(error);
        }
        if (result) {
          console.log(result)
          myContract.methods.companies(result).call(function (error, data) {
            if (error) {
              resolve(error);
              console.log(error);
            }
            if (data) {
              data["companyid"] = result;
              console.log(data)
              resolve(data);
              // console.log(data);
            }
          })

        }
      });
    }) as Promise<any>;
  }

  addcompany(data) {
    console.log(data);
    const tx = {
      to: contractAddress,
      gas: 3000000,
      data: myContract.methods.addCompany(data.companyname, data.publicaddress, data.dochash).encodeABI()
    }
    var signature = web3.eth.accounts.sign('0x2CFF1b13109Aa1b78847Ec22eF6B6D6dEb72a996', '0x81ED94E347EAA804802C716AAB5D00FEB343ED4BA7D8149B6349AC0D3C41F6DC');
    console.log(signature);
    return new Promise((resolve, reject) => {
      web3.eth.accounts.signTransaction(tx, privatekey, (err, data) => {
        if (err) {
          console.log(err);
          resolve(err);
        }
        if (data) {
          console.log(data)
          web3.eth.sendSignedTransaction(data['rawTransaction']).on('transactionHash', txHash => {
            console.log("txHash", txHash);
            this.txstatus(txHash).then(result => {
              console.log(result)
              if (result == "success") {
                resolve(result);
                this.toster.success('success', 'Transaction Status');
              }
              if (result == "failed") {
                resolve(result);
                this.toster.error('error', 'Transaction Status');
              }
            })
          })
        }
      })
    }).catch(e => {
      console.log(e)
    })

  }

  public async updatecompany(data): Promise<any> {

    console.log(data);

    const tx = {
      to: contractAddress,
      gas: 3000000,
      data: myContract.methods.updateCompanyAddress(data.companyid, data.address, data.dochash).encodeABI()
    }

    return new Promise((resolve, reject) => {
      web3.eth.accounts.signTransaction(tx, privatekey, (err, data) => {
        if (err) {
          console.log(err);
          resolve(err);

        }
        if (data) {
          web3.eth.sendSignedTransaction(data['rawTransaction']).on('transactionHash', txHash => {
            console.log("txHash", txHash);
            this.txstatus(txHash).then(result => {
              console.log(result)
              if (result == "success") {
                resolve(result);
                this.toster.success('success', 'Transaction Status');
              }
              if (result == "failed") {
                resolve(result);
                this.toster.error('error', 'Transaction Status');
              }
            })
          })

        }
      })
    }) as Promise<any>;

  }


  addindividual(data) {
    console.log(data);
    const tx = {
      to: contractAddress,
      gas: 3000000,
      data: myContract.methods.addIndividual(data.Individualname, data.Individualaddress, data.Individualdochash).encodeABI()
    }

    return new Promise((resolve, reject) => {
      web3.eth.accounts.signTransaction(tx, privatekey, (err, data) => {
        if (err) {
          console.log(err);
          resolve(err);
        }
        if (data) {
          console.log(data)
          web3.eth.sendSignedTransaction(data['rawTransaction']).on('transactionHash', txHash => {
            console.log("txHash", txHash);
            this.txstatus(txHash).then(result => {
              console.log(result)
              if (result == "success") {
                resolve(result);
                this.toster.success('success', 'Transaction Status');
              }
              if (result == "failed") {
                resolve(result);
                this.toster.error('error', 'Transaction Status');
              }
            })
          })
        }
      })
    }).catch(e => {
      console.log(e)
    })

  }

  public async getindividualDetails(dataaddress): Promise<any> {
    return new Promise((resolve, reject) => {
      myContract.methods.addressToIndiv(dataaddress).call(function (error, result) {
        if (error) {
          console.log(error)
          resolve(error);
        }
        if (result) {
          console.log(result)
          myContract.methods.individuals(result).call(function (error, data) {
            if (error) {
              resolve(error);
              console.log(error);
            }
            if (data) {
              data["individualid"] = result;
              // console.log(data)
              resolve(data);
              // console.log(data);
            }
          })

        }
      });
    }) as Promise<any>;
  }

  public async updateindividual(data): Promise<any> {
    console.log(data);
    const tx = {
      to: contractAddress,
      gas: 3000000,
      data: myContract.methods.updateIndividualAddress(data.Individualid, data.address, data.dochash).encodeABI()
    }

    return new Promise((resolve, reject) => {
      web3.eth.accounts.signTransaction(tx, privatekey, (err, data) => {
        if (err) {
          console.log(err);
          resolve(err);

        }
        if (data) {
          web3.eth.sendSignedTransaction(data['rawTransaction']).on('transactionHash', txHash => {
            console.log("txHash", txHash);
            this.txstatus(txHash).then(result => {
              console.log(result)
              if (result == "success") {
                resolve(result);
                this.toster.success('success', 'Transaction Status');
              }
              if (result == "failed") {
                resolve(result);
                this.toster.error('error', 'Transaction Status');
              }
            })
          })

        }
      })
    }) as Promise<any>;

  }

  addemployee(data) {
    console.log(data);    
    const tx = {
      to: contractAddress,
      gas: 3000000,
      data: myContract.methods.addEmployee(data.Employeename, data.Employeeaddress, data.Employeedochash,data.Employeecompanyid,data.Employeecompanysign).encodeABI()
    }
   var signature = web3.eth.accounts.sign('0x2CFF1b13109Aa1b78847Ec22eF6B6D6dEb72a996', '0x81ED94E347EAA804802C716AAB5D00FEB343ED4BA7D8149B6349AC0D3C41F6DC');
    console.log(signature);
    
    return new Promise((resolve, reject) => {
      web3.eth.accounts.signTransaction(tx, privatekey, (err, data) => {
        if (err) {
          console.log(err);
          resolve(err);
        }
        if (data) {
          console.log(data)
          web3.eth.sendSignedTransaction(data['rawTransaction']).on('transactionHash', txHash => {
            console.log("txHash", txHash);
            this.txstatus(txHash).then(result => {
              console.log(result)
              if (result == "success") {
                resolve(result);
                this.toster.success('success', 'Transaction Status');
              }
              if (result == "failed") {
                resolve(result);
                this.toster.error('error', 'Transaction Status');
              }
            })
          })
        }
      })
    }).catch(e => {
      console.log(e)
    })

  }


}
